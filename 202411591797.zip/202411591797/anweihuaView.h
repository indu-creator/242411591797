﻿
// anweihuaView.h: CanweihuaView 类的接口
//

#pragma once


class CanweihuaView : public CView
{
protected: // 仅从序列化创建
	CanweihuaView() noexcept;
	DECLARE_DYNCREATE(CanweihuaView)


	int m_GLPixelIndex;
	HGLRC m_hGLContext;
// 特性
public:
	CanweihuaDoc* GetDocument() const;

// 操作
public:
	float m_xrotation;
	float m_yrotation;

	BOOL mloftButtonDown;
	CPoint m_leftDownPos;

	float control_point[4][2];
	void DrawScene(void);
// 重写
public:
	virtual void OnDraw(CDC* pDC);  // 重写以绘制该视图
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
protected:
	virtual BOOL OnPreparePrinting(CPrintInfo* pInfo);
	virtual void OnBeginPrinting(CDC* pDC, CPrintInfo* pInfo);
	virtual void OnEndPrinting(CDC* pDC, CPrintInfo* pInfo);

	BOOL SetWindowPixelFormat(HDC hDC);
	BOOL CreateViewGLContext(HDC hDC);

// 实现
public:
	virtual ~CanweihuaView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// 生成的消息映射函数
protected:
	DECLARE_MESSAGE_MAP()
public:
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnDestroy();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnOpenDlg();
};

#ifndef _DEBUG  // anweihuaView.cpp 中的调试版本
inline CanweihuaDoc* CanweihuaView::GetDocument() const
   { return reinterpret_cast<CanweihuaDoc*>(m_pDocument); }
#endif

