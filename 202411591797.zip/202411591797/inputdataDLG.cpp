﻿// inputdataDLG.cpp: 实现文件
//

#include "pch.h"
#include "anweihua.h"
#include "afxdialogex.h"
#include "inputdataDLG.h"


// inputdataDLG 对话框

IMPLEMENT_DYNAMIC(inputdataDLG, CDialogEx)

inputdataDLG::inputdataDLG(CWnd* pParent /*=nullptr*/)
	: CDialogEx(IDD_DIALOG1, pParent)
	, point1x(0)
	, point1y(0)
{

}

inputdataDLG::~inputdataDLG()
{
}

void inputdataDLG::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_Point1x, point1x);
	DDX_Text(pDX, IDC_Point1y, point1y);
}


BEGIN_MESSAGE_MAP(inputdataDLG, CDialogEx)
END_MESSAGE_MAP()


// inputdataDLG 消息处理程序
