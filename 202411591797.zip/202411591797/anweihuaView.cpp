﻿
// anweihuaView.cpp: CanweihuaView 类的实现
//

#include "pch.h"
#include "framework.h"
// SHARED_HANDLERS 可以在实现预览、缩略图和搜索筛选器句柄的
// ATL 项目中进行定义，并允许与该项目共享文档代码。
#ifndef SHARED_HANDLERS
#include "anweihua.h"
#endif

#include "anweihuaDoc.h"
#include "anweihuaView.h"
#include"inputdataDLG.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// CanweihuaView

IMPLEMENT_DYNCREATE(CanweihuaView, CView)

BEGIN_MESSAGE_MAP(CanweihuaView, CView)
	// 标准打印命令
	ON_COMMAND(ID_FILE_PRINT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_DIRECT, &CView::OnFilePrint)
	ON_COMMAND(ID_FILE_PRINT_PREVIEW, &CView::OnFilePrintPreview)
	ON_WM_CREATE()
	ON_WM_DESTROY()
	ON_WM_SIZE()
	ON_WM_ERASEBKGND()
	ON_COMMAND(ID_open_dlg, &CanweihuaView::OnOpenDlg)
END_MESSAGE_MAP()

// CanweihuaView 构造/析构

CanweihuaView::CanweihuaView() noexcept
{
	// TODO: 在此处添加构造代码
	this->m_GLPixelIndex = 0;
	this->m_hGLContext = NULL;
	// 赋值
	control_point[0][0] = -3;
	control_point[0][1] = -3;
	control_point[1][0] = -1;
	control_point[1][1] = 3;
	control_point[2][0] = 1;
	control_point[2][1] = -3;
	control_point[3][0] = 3;
	control_point[3][1] = 3;

}

CanweihuaView::~CanweihuaView()
{
}

BOOL CanweihuaView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: 在此处通过修改
	//  CREATESTRUCT cs 来修改窗口类或样式
	cs.style |= (WS_CLIPCHILDREN | WS_CLIPSIBLINGS);

	return CView::PreCreateWindow(cs);
}

// CanweihuaView 绘图

void CanweihuaView::OnDraw(CDC* pDC)
{
	CanweihuaDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	if (!pDoc)
		return;

	// 清除颜色和深度缓冲区
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

	// 设置矩阵模式，准备绘图
	glMatrixMode(GL_MODELVIEW);
	glLoadIdentity();
	glRotatef(m_xrotation, 1.0, 0.0, 0.0);
	glRotatef(m_yrotation, 0.0, 1.0, 0.0);

	DrawScene();

	SwapBuffers(pDC->m_hDC);

}


// CanweihuaView 打印

BOOL CanweihuaView::OnPreparePrinting(CPrintInfo* pInfo)
{
	// 默认准备
	return DoPreparePrinting(pInfo);
}

void CanweihuaView::OnBeginPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加额外的打印前进行的初始化过程
}

void CanweihuaView::OnEndPrinting(CDC* /*pDC*/, CPrintInfo* /*pInfo*/)
{
	// TODO: 添加打印后进行的清理过程
}


// CanweihuaView 诊断

#ifdef _DEBUG
void CanweihuaView::AssertValid() const
{
	CView::AssertValid();
}

void CanweihuaView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CanweihuaDoc* CanweihuaView::GetDocument() const // 非调试版本是内联的
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CanweihuaDoc)));
	return (CanweihuaDoc*)m_pDocument;
}
#endif //_DEBUG


// CanweihuaView 消息处理程序
BOOL CanweihuaView::SetWindowPixelFormat(HDC hDC)
{
	PIXELFORMATDESCRIPTOR  pixelDesc = { sizeof(PIXELFORMATDESCRIPTOR), 1,
																			   PFD_DRAW_TO_WINDOW |
																			   PFD_SUPPORT_OPENGL |
																			   PFD_DOUBLEBUFFER,
																			   PFD_TYPE_RGBA,   24,  0,0,0,0,0,0,  0,  0,  0,
																			   0,0,0,0,  32,   0,  0, 0,  0,  0,0,0 };
	m_GLPixelIndex = ChoosePixelFormat(hDC, &pixelDesc);

	if (m_GLPixelIndex == 0)
	{
		return FALSE;
	}

	if (SetPixelFormat(hDC, m_GLPixelIndex, &pixelDesc) == FALSE)
	{
		return FALSE;
	}

	return TRUE;
}


BOOL CanweihuaView::CreateViewGLContext(HDC hDC)
{
	m_hGLContext = wglCreateContext(hDC);
	if (m_hGLContext == NULL) //创建失败
	{
		return FALSE;
	}

	if (wglMakeCurrent(hDC, m_hGLContext) == FALSE)
	{//选为当前RC失败
		return FALSE;
	}
	return TRUE;

}


int CanweihuaView::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CView::OnCreate(lpCreateStruct) == -1)
		return -1;

	// TODO:  在此添加您专用的创建代码
	HWND hWnd = this->GetSafeHwnd();
	HDC hDC = ::GetDC(hWnd);

	if (this->SetWindowPixelFormat(hDC) == FALSE)
	{
		return 0;
	}

	if (this->CreateViewGLContext(hDC) == FALSE)
	{
		return 0;
	}

	///////////////////
	glewInit();
	glDrawBuffer(GL_BACK);
	glClearColor(1.0f, 1.0f, 1.0f, 1.0f);
	glClearDepth(1.0);

	glEnable(GL_DEPTH_TEST);
	glDepthFunc(GL_LESS);

	///////////////////

	return 0;
}

void CanweihuaView::OnDestroy()
{
	CView::OnDestroy();

	// TODO: 在此处添加消息处理程序代码
	if (wglGetCurrentContext() != NULL)
	{
		wglMakeCurrent(NULL, NULL);
	}

	if (this->m_hGLContext != NULL)
	{
		wglDeleteContext(this->m_hGLContext);
		this->m_hGLContext = NULL;
	}

}

void CanweihuaView::OnSize(UINT nType, int cx, int cy)
{
	CView::OnSize(nType, cx, cy);

	// TODO: 在此处添加消息处理程序代码
	glViewport(0, 0, cx, cy);
	GLdouble aspect;
	if (cy == 0)
	{
		aspect = (GLdouble)cx;
	}
	else
	{
		aspect = (GLdouble)cx / (GLdouble)cy;
	}

	glMatrixMode(GL_PROJECTION);
	glLoadIdentity();
	glOrtho(-5.0 * aspect, 5.0 * aspect, -5.0, 5.0, -13.0, 13.0);
	Invalidate();

}

BOOL CanweihuaView::OnEraseBkgnd(CDC* pDC)
{
	// TODO: 在此添加消息处理程序代码和/或调用默认值

	//return CView::OnEraseBkgnd(pDC);

	return TRUE;
}


void CanweihuaView::DrawScene(void)
{
	
	/*inputdataDLG m_dlg;
	if (m_dlg.DoModal() == IDOK) {
		
		control_point[0][0] = m_dlg.point1x;
		control_point[0][1] = m_dlg.point1y;
		
	}*/

	

	//循环
	float temp_point[4][2];
	glColor3f(1.0f, 0.0f, 0.0f);
	glLineWidth(3.0f);
	glBegin(GL_LINE_STRIP);
	for (int loop = 0; loop <= 50; loop++)
	{

		for (int i = 0; i <= 3; i++)
		{
			temp_point[i][0] = control_point[i][0];
			temp_point[i][1] = control_point[i][1];
		}

		for (int s = 1; s <= 3; s++)
		{
			for (int i = 0; i <= 3 - s; i++)
			{
				temp_point[i][0] = (1 - loop / 50.0f) * temp_point[i][0] + (loop / 50.0f) * temp_point[i + 1][0];
				temp_point[i][1] = (1 - loop / 50.0f) * temp_point[i][1] + (loop / 50.0f) * temp_point[i + 1][1];
			}
		}


		glVertex2f(temp_point[0][0], temp_point[0][1]);
	}

	glEnd(); // 结束绘制
}

void CanweihuaView::OnOpenDlg()
{
	inputdataDLG m_dlg;

	if (m_dlg.DoModal() == IDOK) {

		control_point[0][0] = m_dlg.point1x;
		control_point[0][1] = m_dlg.point1y;

	}
	// TODO: 在此添加命令处理程序代码
	Invalidate();
}
