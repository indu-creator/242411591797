﻿#pragma once
#include "afxdialogex.h"


// inputdataDLG 对话框

class inputdataDLG : public CDialogEx
{
	DECLARE_DYNAMIC(inputdataDLG)

public:
	inputdataDLG(CWnd* pParent = nullptr);   // 标准构造函数
	virtual ~inputdataDLG();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_DIALOG1 };
#endif

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

	DECLARE_MESSAGE_MAP()
public:
	float point1x;
	float point1y;
};
